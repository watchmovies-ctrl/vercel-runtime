import os
class Config:
    SECRET_KEY = 'v8_functional_secret'
    DB_NAME = "smartfactory_v8.db"
    SHIFT_HOURS = 8.0
